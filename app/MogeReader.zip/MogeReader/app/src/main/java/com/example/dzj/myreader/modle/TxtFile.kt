package com.example.dzj.myreader.modle

import android.os.Parcelable
import androidx.versionedparcelable.ParcelField

@ParcelField
class TxtFile : Parcelable {
    var name: String? = null
    var path: String? = null
    var size: String? = null
    var lastModified: Long = 0
    var isDirectory: Boolean = false

    var id: Int = 0
    var charset: String? = null
    var chapter: Int = 0
    var page: Int = 0
    var chapterNum: Int = 0
    var sequence: Int = 0
    var hasForeword: Int = 0

    constructor() {

    }

    constructor(name: String, path: String, lastModified: Long, size: String, isDirectory: Boolean) {
        this.name = name
        this.path = path
        this.lastModified = lastModified
        this.size = size
        this.isDirectory = isDirectory
    }

    override fun toString(): String {
        return ("name=" + name
                + "\npath=" + path
                + "\ncharset=" + charset
                + "\nchapter=" + chapter
                + "\npage=" + page
                + "\nchapterNum=" + chapterNum
                + "\nsequence=" + sequence
                + "\nhasForeword=" + hasForeword)
    }
}
