package com.example.dzj.myreader.minterface;

/**
 * Created by dzj on 2017/8/26.
 */

public interface ChooseAllCheckBox {
    void chooseClick(boolean a);
}
